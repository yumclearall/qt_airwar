#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QUdpSocket>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr, QString name = nullptr);
    ~Widget();

    //重写关闭事件
    void closeEvent(QCloseEvent *);

    enum Msgtype{Msg,UserEnter,UserLeft};   //枚举， 普通信息，用户进入，用户离开
    void sendMsg(Msgtype type);     //广播udp信息
    QString getName();      //获取名字
    QString gerMsg();       //获取聊天信息
    void userEnter(QString username);   //处理用户进入
    void userLeft(QString username, QString time);    //处理用户离开
    void ReceiveMessage();     //接udp信息


signals:


    void closeWidget();

private:
    quint16 port;   //端口
    QUdpSocket *udpSocket;  //套接字
    Ui::Widget *ui;
    QString myName;  //名字


};

#endif // WIDGET_H
