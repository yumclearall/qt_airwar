#include "login.h"
#include "ui_login.h"

#include <QToolButton>
#include "widget.h"
#include <QMessageBox>

Login::Login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
    //设置图标
    //路径 ： 冒号 + 前缀 + 路径
    this->setWindowIcon(QIcon("://image/Saw.png"));
    //设置名称
    this->setWindowTitle("QtChat");

    QList<QString> nameList;//名字
    nameList  << "01" << "02" << "03" << "04" << "05" << "06" << "07";
    QList<QString> iconList;//图标资源列表
    iconList << "Alien" << "Amityville" << "It" << "Sasquatch" << "Jason" << "Nevermore" << "Nosferatu";

    QVector<QToolButton*> vc;

    for (int i = 0; i <= 6; i++) {

        QToolButton *btn = new QToolButton(this);
        //加载图片
        QPixmap pix(QString("://image/%1.png").arg(iconList[i]));
        btn->setIcon(pix);
        //设置大小
        btn->setIconSize(pix.size());
        //网名
        btn->setText(nameList[i]);
        //图片显示
        btn->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
        //透明
        btn->setAutoRaise(true);
        //放入窗口
        ui->vlayout->addWidget(btn);
        //放到数组中
        vc.push_back(btn);
        book.push_back(false);

    }
    for (int i = 0; i< vc.size(); i++){

        connect(vc[i],&QToolButton::clicked,[=](){
            if (book[i]){
                QMessageBox::warning(this,"警告","该聊天窗口不可重复打开！");
                return;
            }
            Widget *w = new Widget(nullptr,vc[i]->text());
            w->setWindowIcon(vc[i]->icon());
            w->setWindowTitle(vc[i]->text());
            book[i] = true;
            w->show();

            //关闭时将对应的book变为false
            connect(w,&Widget::closeWidget,this,[=](){
                book[i] = false;
            });
        });
    }

}

Login::~Login()
{
    delete ui;
}
