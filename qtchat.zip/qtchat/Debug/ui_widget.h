/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFontComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QWidget *widget_2;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_3;
    QTextEdit *textEdit;
    QWidget *widget1;
    QVBoxLayout *verticalLayout;
    QWidget *widget_1;
    QHBoxLayout *horizontalLayout_2;
    QTextBrowser *textBrowser;
    QFrame *frame;
    QHBoxLayout *horizontalLayout;
    QFontComboBox *fontComboBox;
    QComboBox *comboBox;
    QToolButton *tbtn_B;
    QToolButton *tbtn_I;
    QToolButton *tbtn_U;
    QToolButton *tbtn_Color;
    QToolButton *tbtn__Save;
    QToolButton *tbtn_Delete;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *sendbtn;
    QSpacerItem *horizontalSpacer;
    QLabel *log_num;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *exitbtn;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_5;
    QTableWidget *tableWidget;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(800, 600);
        widget_2 = new QWidget(Widget);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setEnabled(true);
        widget_2->setGeometry(QRect(0, 0, 501, 500));
        widget_2->setInputMethodHints(Qt::ImhNone);
        widget = new QWidget(widget_2);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(100, 360, 268, 204));
        horizontalLayout_3 = new QHBoxLayout(widget);
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        textEdit = new QTextEdit(widget_2);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(30, 270, 461, 204));
        widget1 = new QWidget(widget_2);
        widget1->setObjectName(QStringLiteral("widget1"));
        widget1->setGeometry(QRect(30, 20, 464, 246));
        verticalLayout = new QVBoxLayout(widget1);
        verticalLayout->setSpacing(0);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        widget_1 = new QWidget(widget1);
        widget_1->setObjectName(QStringLiteral("widget_1"));
        horizontalLayout_2 = new QHBoxLayout(widget_1);
        horizontalLayout_2->setSpacing(0);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        textBrowser = new QTextBrowser(widget_1);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));

        horizontalLayout_2->addWidget(textBrowser);


        verticalLayout->addWidget(widget_1);

        frame = new QFrame(widget1);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setFrameShape(QFrame::Box);
        horizontalLayout = new QHBoxLayout(frame);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        fontComboBox = new QFontComboBox(frame);
        fontComboBox->setObjectName(QStringLiteral("fontComboBox"));

        horizontalLayout->addWidget(fontComboBox);

        comboBox = new QComboBox(frame);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setSizeAdjustPolicy(QComboBox::AdjustToContents);

        horizontalLayout->addWidget(comboBox);

        tbtn_B = new QToolButton(frame);
        tbtn_B->setObjectName(QStringLiteral("tbtn_B"));
        tbtn_B->setCheckable(true);

        horizontalLayout->addWidget(tbtn_B);

        tbtn_I = new QToolButton(frame);
        tbtn_I->setObjectName(QStringLiteral("tbtn_I"));
        tbtn_I->setCheckable(true);

        horizontalLayout->addWidget(tbtn_I);

        tbtn_U = new QToolButton(frame);
        tbtn_U->setObjectName(QStringLiteral("tbtn_U"));
        tbtn_U->setCheckable(true);

        horizontalLayout->addWidget(tbtn_U);

        tbtn_Color = new QToolButton(frame);
        tbtn_Color->setObjectName(QStringLiteral("tbtn_Color"));

        horizontalLayout->addWidget(tbtn_Color);

        tbtn__Save = new QToolButton(frame);
        tbtn__Save->setObjectName(QStringLiteral("tbtn__Save"));

        horizontalLayout->addWidget(tbtn__Save);

        tbtn_Delete = new QToolButton(frame);
        tbtn_Delete->setObjectName(QStringLiteral("tbtn_Delete"));

        horizontalLayout->addWidget(tbtn_Delete);


        verticalLayout->addWidget(frame);

        widget_3 = new QWidget(Widget);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setGeometry(QRect(30, 490, 461, 51));
        horizontalLayout_4 = new QHBoxLayout(widget_3);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        sendbtn = new QPushButton(widget_3);
        sendbtn->setObjectName(QStringLiteral("sendbtn"));
        sendbtn->setEnabled(true);

        horizontalLayout_4->addWidget(sendbtn);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        log_num = new QLabel(widget_3);
        log_num->setObjectName(QStringLiteral("log_num"));

        horizontalLayout_4->addWidget(log_num);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);

        exitbtn = new QPushButton(widget_3);
        exitbtn->setObjectName(QStringLiteral("exitbtn"));

        horizontalLayout_4->addWidget(exitbtn);

        widget_4 = new QWidget(Widget);
        widget_4->setObjectName(QStringLiteral("widget_4"));
        widget_4->setGeometry(QRect(500, 20, 280, 500));
        horizontalLayout_5 = new QHBoxLayout(widget_4);
        horizontalLayout_5->setSpacing(0);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        tableWidget = new QTableWidget(widget_4);
        if (tableWidget->columnCount() < 1)
            tableWidget->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));

        horizontalLayout_5->addWidget(tableWidget);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", Q_NULLPTR));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("Widget", "5", Q_NULLPTR)
         << QApplication::translate("Widget", "6", Q_NULLPTR)
         << QApplication::translate("Widget", "7", Q_NULLPTR)
         << QApplication::translate("Widget", "8", Q_NULLPTR)
         << QApplication::translate("Widget", "9", Q_NULLPTR)
         << QApplication::translate("Widget", "10", Q_NULLPTR)
         << QApplication::translate("Widget", "11", Q_NULLPTR)
         << QApplication::translate("Widget", "12", Q_NULLPTR)
        );
#ifndef QT_NO_STATUSTIP
        tbtn_B->setStatusTip(QApplication::translate("Widget", "\345\212\240\347\262\227", Q_NULLPTR));
#endif // QT_NO_STATUSTIP
        tbtn_B->setText(QApplication::translate("Widget", "B", Q_NULLPTR));
#ifndef QT_NO_STATUSTIP
        tbtn_I->setStatusTip(QApplication::translate("Widget", "\345\200\276\346\226\234", Q_NULLPTR));
#endif // QT_NO_STATUSTIP
        tbtn_I->setText(QApplication::translate("Widget", "I", Q_NULLPTR));
#ifndef QT_NO_STATUSTIP
        tbtn_U->setStatusTip(QApplication::translate("Widget", "\344\270\213\345\210\222\347\272\277", Q_NULLPTR));
#endif // QT_NO_STATUSTIP
        tbtn_U->setText(QApplication::translate("Widget", "U", Q_NULLPTR));
#ifndef QT_NO_STATUSTIP
        tbtn_Color->setStatusTip(QApplication::translate("Widget", "\351\242\234\350\211\262", Q_NULLPTR));
#endif // QT_NO_STATUSTIP
        tbtn_Color->setText(QApplication::translate("Widget", "C", Q_NULLPTR));
#ifndef QT_NO_STATUSTIP
        tbtn__Save->setStatusTip(QApplication::translate("Widget", "\344\277\235\345\255\230", Q_NULLPTR));
#endif // QT_NO_STATUSTIP
        tbtn__Save->setText(QApplication::translate("Widget", "S", Q_NULLPTR));
#ifndef QT_NO_STATUSTIP
        tbtn_Delete->setStatusTip(QApplication::translate("Widget", "\346\270\205\347\251\272", Q_NULLPTR));
#endif // QT_NO_STATUSTIP
        tbtn_Delete->setText(QApplication::translate("Widget", "D", Q_NULLPTR));
        sendbtn->setText(QApplication::translate("Widget", "\345\217\221\351\200\201", Q_NULLPTR));
        log_num->setText(QApplication::translate("Widget", "\345\234\250\347\272\277\344\272\272\346\225\260\357\274\2320\344\272\272", Q_NULLPTR));
        exitbtn->setText(QApplication::translate("Widget", "\351\200\200\345\207\272", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("Widget", "\347\224\250\346\210\267\345\220\215\357\274\232", Q_NULLPTR));
#ifndef QT_NO_WHATSTHIS
        tableWidget->setWhatsThis(QApplication::translate("Widget", "<html><head/><body><p>\347\224\250\346\210\267\345\220\215</p></body></html>", Q_NULLPTR));
#endif // QT_NO_WHATSTHIS
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
