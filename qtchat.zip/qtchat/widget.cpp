#include "widget.h"
#include "ui_widget.h"
#include <QDateTime>
#include <QColorDialog>
#include <QFileDialog>

Widget::Widget(QWidget *parent, QString name) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    myName = name;
    //创建端口和套接字
    this->port = 9999;
    this->udpSocket = new QUdpSocket(this);

    //绑定端口
    udpSocket->bind(port,QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);

    //接收信号
    connect(udpSocket,&QUdpSocket::readyRead,this,&Widget::ReceiveMessage);

    //连接发送按钮
    connect(ui->sendbtn,&QPushButton::clicked,[=](){
        this->sendMsg(Widget::Msg);
    });

    //新用户进入
    this->sendMsg(UserEnter);

    //退出按钮
    connect(ui->exitbtn,&QPushButton::clicked,[=](){
       this->sendMsg(UserLeft);
       this->close();
    });

    //设置字体
    connect(ui->fontComboBox,&QFontComboBox::currentFontChanged,[=](const QFont font){
        ui->textEdit->setFontFamily(font.toString());
        ui->textEdit->setFocus();
    });

    //设置字体大小
    void (QComboBox:: * sizebtn)(const QString &text) = &QComboBox::currentTextChanged;
    connect(ui->comboBox,sizebtn,[=](const QString &text){
        ui->textEdit->setFontPointSize(text.toDouble());
        ui->textEdit->setFocus();
    });

    //加粗
    connect(ui->tbtn_B,&QPushButton::clicked,[=](bool checked){
        if (checked){
            ui->textEdit->setFontWeight(QFont::Bold);
            ui->textEdit->setFocus();
        }else {
            ui->textEdit->setFontWeight(QFont::Normal);
            ui->textEdit->setFocus();
        }
    });

    //倾斜
    connect(ui->tbtn_I,&QPushButton::clicked,[=](bool checked){
        ui->textEdit->setFontItalic(checked);
        ui->textEdit->setFocus();
    });

    //下划线
    connect(ui->tbtn_U,&QPushButton::clicked,[=](bool checked){
        ui->textEdit->setFontUnderline(checked);
        ui->textEdit->setFocus();
    });

    //清空
    connect(ui->tbtn_Delete,&QPushButton::clicked,[=](){
        ui->textEdit->clear();
    });

    //颜色
    connect(ui->tbtn_Color,&QToolButton::clicked,[=](){
        QColor color = QColorDialog::getColor(color,this);
        ui->textEdit->setTextColor(color);
    });

    //保存聊天记录
    connect(ui->tbtn__Save,&QToolButton::clicked,[=](){
        if(ui->textBrowser->document()->isEmpty())
            return;
        QString filename = QFileDialog::getSaveFileName(this,"保存聊天记录","聊天记录","(.txt)");
        if (!filename.isEmpty()){
            //保存名称不为空，进行保存
            QFile file(filename);
            file.open(QIODevice::WriteOnly | QFile::Text);
            QTextStream stream(&file);
            stream << ui->textBrowser->toPlainText();
            file.close();
        }

    });


}

Widget::~Widget()
{
    delete ui;
}

void Widget::closeEvent(QCloseEvent *)
{
    emit this->closeWidget();
    this->sendMsg(UserLeft);
    udpSocket->close();
    udpSocket->destroyed();
}

void Widget::sendMsg(Widget::Msgtype type)
{
    QByteArray array;//创建数组
    //创建流 好处可以分段 参数1流入的地址 参数2 只能写
    QDataStream stream(&array,QIODevice::WriteOnly);
    stream << type << this->getName(); //流入 类型和用户姓名
    if (type == Widget::Msg && this->ui->textEdit->toPlainText() != ""){
        stream << this->gerMsg();//流入 普通聊天信息
    }

    //书写报文
    udpSocket->writeDatagram(array.data(),array.size(),QHostAddress::Broadcast,this->port);
}

QString Widget::getName()
{
    return this->myName;
}

QString Widget::gerMsg()
{
    QString msg = ui->textEdit->toHtml();   //返回输入框中的内容
    ui->textEdit->clear();//清空输入框
    ui->textEdit->setFocus();//设置光标
    return msg;
}

void Widget::userEnter(QString username)
{
    bool isEmpty = ui->tableWidget->findItems(username,Qt::MatchExactly).isEmpty();
    if (isEmpty){
        QTableWidgetItem *user = new QTableWidgetItem(username);
        ui->tableWidget->insertRow(0);
        ui->tableWidget->setItem(0,0,user);
        ui->textBrowser->setTextColor(Qt::gray);
        ui->textBrowser->append(username + "已上线");
        ui->log_num->setText(QString("在线人数：%1人").arg(ui->tableWidget->rowCount()));

        this->sendMsg(UserEnter);
    }
}

void Widget::userLeft(QString username, QString time)
{
    bool isEmpty = ui->tableWidget->findItems(username,Qt::MatchExactly).isEmpty();
    if (!isEmpty){
        //寻找行
        int row = ui->tableWidget->findItems(username,Qt::MatchExactly).first()->row();
        //移除该行
        ui->tableWidget->removeRow(row);

        //追加信息
        ui->textBrowser->setTextColor(Qt::gray);
        ui->textBrowser->append(username + "于" + time + "下线");
        ui->log_num->setText(QString("在线人数：%1人").arg(ui->tableWidget->rowCount()));

    }
}

void Widget::ReceiveMessage()
{
    qint64 size = udpSocket->pendingDatagramSize();
    //qint64变int
    int mysize = static_cast<int>(size);
    QByteArray *array = new QByteArray(mysize,0);
    udpSocket->readDatagram((*array).data(),size);
    QDataStream stream(array,QIODevice::ReadOnly);
    int msgtype;
    stream >> msgtype;  //读取类型
    QString name,msg;   //用户名 聊天信息
    QString time = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");//获取当前时间

    switch (msgtype) {
    case Widget::Msg://普通聊天
        stream >> name >> msg;  //流出姓名和聊天内容

        //增加聊天记录
        ui->textBrowser->setTextColor(Qt::blue);
        ui->textBrowser->setCurrentFont(QFont("Times New Roman",12));
        ui->textBrowser->append("[" + name + "] " + time);
        ui->textBrowser->append(msg);
        break;
    case Widget::UserEnter://进入
        stream >> name;
        userEnter(name);
        break;
    case Widget::UserLeft://离开
        stream >> name;
        userLeft(name,time);
        break;

    }

}
















