#ifndef ENEMYBULLET_H
#define ENEMYBULLET_H

#include "Bullet.h"

class EnemyBullet : public Bullet
{
public:
    EnemyBullet(QObject *parent = nullptr);
    void PlaySound();
};

#endif // ENEMYBULLET_H
