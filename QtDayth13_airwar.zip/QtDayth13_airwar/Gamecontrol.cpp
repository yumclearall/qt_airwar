#include "Gamecontrol.h"
#include "GameObjectpool.h"

GameControl* GameControl::instance = nullptr;
GameControl::GameControl()
{
    this->setParent(Widget::widget);   //设置父亲
}

void GameControl::GameInit(){


    //对象池初始化
    GameObjectPool::Instance()->Init();

    //设置视图父亲为窗口
    mGameView.setParent(Widget::widget);
    //mGameView.show();


    LoadStartScence();//开始场景初始化



    //定时器初始化

    //开启背景移动定时器
    mBGMoveTimer = new QTimer(this);
    //开启发射定时器
    mPLaneShootTimer = new QTimer(this);
    //开启子弹移动定时器
    mBulletMoveTimer = new QTimer(this);
    //开启敌机创建定时器
    mEnemyCreateTimer = new QTimer(this);
    //开启敌人移动定时器
    mEnemyMoveTimer = new QTimer(this);
    //飞机移动检测定时器
    mPlaneMoveTimer = new QTimer(this);




    //绑定定时器处理函数

    connect(mBGMoveTimer,&QTimer::timeout,this,&GameControl::BGMove);
    connect(mPLaneShootTimer, &QTimer::timeout, this, &GameControl::PlaneBulletShoot);
    connect(mBulletMoveTimer, &QTimer::timeout,[this](){
        //子弹移动
        for (auto bullet : mBulletList) {

            bullet->BulletMove();
            //越界判断
            if (bullet->y() < -100){
                //移除场景
                //mSence.removeItem(bullet);

                bullet->GameObjectDelete(&mSence);
                //移除容器
                mBulletList.removeOne(bullet);
                //对象池回收
                //GameObjectPool::Instance()->RecoveryGameObject(bullet);
                return;
            }
        }

    });
    connect(mEnemyCreateTimer, &QTimer::timeout,this, &GameControl::CreateEnemy);
    connect(mEnemyMoveTimer,&QTimer::timeout, [this](){
        for (auto i : mEnemyList){
            qDebug() << 4;
            i->EnemyMove();

            if (i->y() > GameDefine::ScreenHeight + i->pixmap().height()){
                //移除场景
                //mSence.removeItem(i);

                i->GameObjectDelete(&mSence);
                //移除容器
                mEnemyList.removeOne(i);
                //对象池回收
                //GameObjectPool::Instance()->RecoveryGameObject(i);
                qDebug() << 4;
                return;
            }
        }
        //碰撞检测
        Collision();

    });
    connect(mPlaneMoveTimer, &QTimer::timeout,this,&GameControl::PlantMove);

}

void GameControl::LoadStartScence()
{
    //mGameView.setSceneRect(QRect(0,0,400,600));
    mSence.setSceneRect(QRect(0,0,400,600));//游戏进行场景大小
    mStartScence.setSceneRect(QRect(0,0,400,600));//游戏开始场景大小
    //开始场景添加图片
    mStartScence.addPixmap(QPixmap("://image/back01.png"));


    //背景音乐  qrc:/ + 前缀名 + 路径
    this->mMediaBG.setMedia(QUrl("qrc:/music/music/bg2.mp3"));
    this->mMediaBG.play();

    QToolButton* startBtn = new QToolButton();
    startBtn->resize(130,50);
    startBtn->setIcon(QIcon("://image/plane.png"));
    startBtn->setText("开始游戏");
    startBtn->setIconSize(QSize(40,50));
    startBtn->move(135,400);
    startBtn->setAutoRaise(true);
    startBtn->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);
    mStartScence.addWidget(startBtn);
    connect(startBtn,&QToolButton::clicked,[this](){

        //加载开始场景
        this->LoadGameScence();
        //开启定时器
        this->GameStart();

    });

    mGameView.setScene(&mStartScence);
    mGameView.show();
}

void GameControl::LoadGameScence()
{



    //开启游戏点击后播放音乐
    //this->mMediaBG = new QMediaPlayer(Widget::widget);
    this->mMediaBG.setMedia(QUrl("qrc:/music/music/bg1.mp3"));
    this->mMediaBG.play();

    mBackGround01.setPixmap(QPixmap("://image/back.png"));//类似QImage
    mBackGround02.setPixmap(QPixmap("://image/back.png"));

    //mPlane.setPixmap(QPixmap("://image/plane.png"));//设置图片

    //设置元素位置
    mBackGround02.setPos(0,-mBackGround02.pixmap().height());



    //图片元素添加到场景
    mSence.addItem(&mBackGround01);
    mSence.addItem(&mBackGround02);
    //mSence.addItem(&mPlane);


    //mGameView.hide();//隐藏
    mSence.addItem(&mMyPlane);



    //mPlane.setPos(165,540);
    //场景添加到视图
    //mGameView.setScene(&mSence);


    //设置当前场景为游戏场景
    mGameView.setScene(&mSence);
    mGameView.show();

}

void GameControl::GameStart()
{
    //开启定时器
    mBGMoveTimer->start(100);
    mPLaneShootTimer->start(GameDefine::PlaneShootUpdateTime);
    mBulletMoveTimer->start(GameDefine::BulletMoveTime);
    mEnemyCreateTimer->start(GameDefine::EnemyCreateTime);
    mEnemyMoveTimer->start(GameDefine::EnemyMoveUpdateTime);
    mPlaneMoveTimer->start(GameDefine::PlayerMoveUpdateTime);
}

void GameControl::GameOver()
{
    //结束逻辑
}


void GameControl::BGMove(){
    mBackGround01.moveBy(0,4);//移动量
    mBackGround02.moveBy(0,4);


    // 设置循环播放
    if (mBackGround01.y() >= mBackGround01.pixmap().height())
        mBackGround01.setY(-mBackGround01.pixmap().height());

    if (mBackGround02.y() >= mBackGround02.pixmap().height())
        mBackGround02.setY(-mBackGround02.pixmap().height());


    //不能超出范围 330,550        窗口宽高 - 飞机宽高

}




void GameControl::PlantMove()
{
    for (int keyCode:mKeyList) {
        switch (keyCode) {
        case Qt::Key_W  :
        case Qt::Key_Up :
            mMyPlane.moveBy(0,-1 * mMyPlane.MoveSpeed());
            break;
        case Qt::Key_S  :
        case Qt::Key_Down :
            mMyPlane.moveBy(0,1 * mMyPlane.MoveSpeed());
            break;
        case Qt::Key_A  :
        case Qt::Key_Left :
            mMyPlane.moveBy(-1 * mMyPlane.MoveSpeed(),0);
            break;
        case Qt::Key_D  :
        case Qt::Key_Right :
            mMyPlane.moveBy(1 * mMyPlane.MoveSpeed(),0);
            break;

        }
    }
    //飞机不超出边界
    if (mMyPlane.x() < 0)
        mMyPlane.setX(0);
    if (mMyPlane.x() > GameDefine::ScreenWidth - mMyPlane.pixmap().width())
        mMyPlane.setX(GameDefine::ScreenWidth - mMyPlane.pixmap().width());
    if (mMyPlane.y() < 0)
        mMyPlane.setY(0);
    if (mMyPlane.y() > GameDefine::ScreenHeight - mMyPlane.pixmap().height())
        mMyPlane.setY(GameDefine::ScreenHeight - mMyPlane.pixmap().height());
}

//我方子弹生成
void GameControl::PlaneBulletShoot()
{
    //创建子弹
    QPixmap pixmap("://image/atk.png");
    QPoint pos(mMyPlane.x() + mMyPlane.pixmap().width()/2 - pixmap.width()/2,mMyPlane.y());
//    Bullet* bullet = new Bullet(pos,pixmap,Bullet::BT_Palyer);

    //对象池构建子弹
    Gameobject* obj = GameObjectPool::Instance()->GetGameObject(Gameobject::OT_BulletPlayer);
    PlayerBullet* bullet = (PlayerBullet*)obj;
    bullet->Init(pos, pixmap);

    bullet->PlaySound();    //播放子弹音效

    //添加到场景
    mSence.addItem(bullet);

    //添加到子弹管理器
    mBulletList.append(bullet);
    qDebug() << 6;
}

void GameControl::Collision()
{
    //遍历子弹
    for (int i = 0; i < mBulletList.size(); i++){
        for (int j = 0; j < mEnemyList.size(); j++){
            //碰撞检测
            if (mBulletList[i]->collidesWithItem(mEnemyList[j])){
                //场景中移除(实际对象并没有被删除）
//                mSence.removeItem(mBulletList[i]);
//                mSence.removeItem(mEnemyList[j]);

                //移除场景并回收对象
                mBulletList[i]->GameObjectDelete(&mSence);
                mEnemyList[j]->GameObjectDelete(&mSence);

                //释放对象
//                delete mBulletList[i];
//                delete mEnemyList[j];

                //音效
                mEnemyList[j]->PlaySound();

                //容器中移除
                mBulletList.removeOne(mBulletList[i]);
                mEnemyList.removeOne(mEnemyList[j]);



                return;
            }
        }

    }
}

void GameControl::CreateEnemy()
{

    QPixmap pixmap((qrand() % 2) ? "://image/enemy2.png" : "://image/enemy1.png");
    int s = qrand() % (400 - pixmap.width());
    QPoint pos(s,-50);
    qDebug() << s;
    //Enemy* enemy = new Enemy(QPoint(s,-100),((s % 2) ? pixmap1 : pixmap2));
    Gameobject* obj = GameObjectPool::Instance()->GetGameObject(Gameobject::OT_Enemy);

    Enemy* enemy = (Enemy*)obj;
    enemy->Init(pos,pixmap);
    //添加到场景
    mSence.addItem(enemy);
    //添加到 管理器
    mEnemyList.append(enemy);


}
