#include "Widget.h"
#include <QApplication>
#include "Gamecontrol.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.show();

    //游戏加载
    GameControl::Insteace()->GameInit();



    return a.exec();
}
