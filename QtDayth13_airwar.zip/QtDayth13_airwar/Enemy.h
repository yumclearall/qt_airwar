#ifndef ENEMY_H
#define ENEMY_H

#include "Plane.h"
#include <QPoint>

class Enemy : public Plane{
    //Q_OBJECT
public:
    Enemy(QObject *parent = nullptr);
    Enemy(QPoint _pos, QPixmap _pixmap);

    void Init(QPoint _pos, QPixmap _pixmap);

    //移动函数
    void EnemyMove(QPoint _dir = QPoint(0,1));

    void PlaySound();

};

#endif // ENEMY_H
