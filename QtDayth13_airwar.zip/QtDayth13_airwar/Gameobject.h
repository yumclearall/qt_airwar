#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H

#include <QGraphicsPixmapItem>
#include <QMediaPlayer>

class Gameobject : public QGraphicsPixmapItem
{
public:

    enum ObjectType{
        OT_BulletPlayer,
        OT_Enemy,
        OT_Player,
        OT_EnemyBullet
    };



    explicit Gameobject(QObject* parent = nullptr);

    int GetType(){
        return  mObjectType;
    }

    //对象回收
    void GameObjectDelete(QGraphicsScene* _scene);

    //音乐播放对象
    QMediaPlayer mBulletMedia;

    //统计对象构造 和析构
    static int createCount;

    ~Gameobject();
protected:
    int mObjectType;
};

#endif // GAMEOBJECT_H
