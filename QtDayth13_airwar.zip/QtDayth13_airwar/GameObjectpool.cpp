#include "GameObjectpool.h"
#include <QDebug>

GameObjectPool* GameObjectPool::instance = nullptr;
GameObjectPool::GameObjectPool(QObject *parent) : QObject(parent)
{

}

void GameObjectPool::Init()
{

    //预先生成对象
    for (int i = 0; i < 20; i++) {
        //我方子弹
        PlayerBullet* bullet = new PlayerBullet();
        mPlayerBulletPoll.append(bullet);

        //敌方子弹
        //EnemyBullet* bullet2 = new EnemyBullet();
       // mEnemyBulletPoll.append(bullet2);

        //敌机
        Enemy* enemy = new Enemy();
        mEnemyPool.append(enemy);

    }
}

Gameobject *GameObjectPool::GetGameObject(int _objectType)

{
    switch (_objectType) {
    case GameObjectPool::OT_BulletPlayer ://子弹
        {
        PlayerBullet* bullet = mPlayerBulletPoll.first();
        mPlayerBulletPoll.pop_front();
        qDebug() << "GetObjectbut";
        return bullet;
        }

    case GameObjectPool::OT_Enemy ://敌机
        {
        Enemy* enemy = mEnemyPool.first();
        mEnemyPool.pop_front();
        qDebug() << "GetObjectene";
        return enemy;
        }

    }
}

void GameObjectPool::RecoveryGameObject(Gameobject *_object)
{
    switch (_object->GetType()) {
        case Gameobject::OT_BulletPlayer : //子弹
    {
        mPlayerBulletPoll.append((PlayerBullet*)_object);
        break;
    }
        case Gameobject::OT_Enemy : //敌机
    {
        mEnemyPool.append((Enemy*)_object);
        break;
    }

    }
}

void GameObjectPool::Clear()
{

    //清除子弹容器
    for (auto i:mPlayerBulletPoll)
        delete i;
    //for (auto i:mEnemyBulletPoll)
       // delete i;

    //清除敌机容器
    for (auto i:mEnemyPool)
        delete i;
}

GameObjectPool::~GameObjectPool()
{
    Clear();    //内存释放
}
