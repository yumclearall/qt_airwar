#ifndef PLANE_H
#define PLANE_H

#include "Gameobject.h"

class Plane : public Gameobject
{
public:
    explicit Plane(QObject *parent = nullptr);

    int MoveSpeed(){
        return mMoveSpeed;
    }
    int ShootSpeed(){
        return mShootSpeed;
    }

protected:
    int mMoveSpeed;
    int mShootSpeed;
};

#endif // PLANE_H
