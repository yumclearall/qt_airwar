#ifndef GAMEOBJECTPOOL_H
#define GAMEOBJECTPOOL_H

#include "Gamedefine.h"



/*
 *
  对象缓存池:当对象被频繁 创建 或 删除 时 大量使用new和delete
  处理堆内存 如果该对象比较大 则对计算机的消耗就越大  很有可能会导致游戏卡顿
  频繁的创建的删除 对计算机的消耗比较大。


  利用对象缓存池 思想 专门处理这个问题

  在对象还没有被使用时 预先缓存 一定数量的对象
  可以有效的解决在创建时导致的卡顿问题
  使用时 直接从对象池中获取对象，
  在对象需要被销毁时，将其回收到对象池中 循环利用
  从而解决对计算机的消耗问题。

 */

class GameObjectPool : public QObject
{
    GameObjectPool(QObject *parent = nullptr);
    static GameObjectPool* instance;
public:

    enum ObjectType{
        OT_BulletPlayer,
        OT_Enemy
    };

    static GameObjectPool* Instance(){
        if (instance == nullptr)
            return instance = new GameObjectPool(Widget::widget);
        return instance;
    }

    //对象池初始化    缓存对象
    void Init();

    //获取对象
    Gameobject* GetGameObject(int _objectType);

    //对象回收
    void RecoveryGameObject(Gameobject *);

    //内存清除
    void Clear();

    ~GameObjectPool();

//    Bullet* CreateBullet();
//    Enemy* CreateEnemy();

protected:
    //子弹对象池容器
    QList<PlayerBullet*> mPlayerBulletPoll;
    //QList<EnemyBullet*> mEnemyBulletPoll;


    //敌机对象池容器
    QList<Enemy*> mEnemyPool;


};

#endif // GAMEOBJECTPOOL_H
