#include "enemybullet.h"

EnemyBullet::EnemyBullet(QObject* parent)
{
    mObjectType = Gameobject::OT_EnemyBullet;
}

void EnemyBullet::PlaySound()
{
    mBulletMedia.setMedia(QUrl("qrc:/music/music/tong.mp3"));
    mBulletMedia.play();
}
