#include "Enemy.h"

Enemy::Enemy(QObject *parent){
    mObjectType = Gameobject::OT_Enemy; //标识对象
    this->mMoveSpeed = 2;
    this->mShootSpeed = 50;
}
Enemy::Enemy(QPoint _pos, QPixmap _pixmap)
{
    this->mMoveSpeed = 2;
    this->mShootSpeed = 500;
    this->setPos(_pos);
    this->setPixmap(_pixmap);

}

void Enemy::Init(QPoint _pos,QPixmap _pixmap)
{
    this->setPos(_pos);
    qDebug() << 9;
    this->setPixmap(_pixmap);

    this->mMoveSpeed = 2;
    this->mShootSpeed = 50;
}

void Enemy::EnemyMove(QPoint _dir)
{
    int Y = (rand() % mMoveSpeed + 1) * mMoveSpeed;
    this->moveBy(0, _dir.y() * Y);
}


void Enemy::PlaySound()
{
    mBulletMedia.setMedia(QUrl("qrc:/music/music/tong.mp3"));
    mBulletMedia.play();
}
