#ifndef MYPLANE_H
#define MYPLANE_H

#include "Plane.h"

class Player : public Plane
{
    //Q_OBJECT
    //QGraphicPixmapItem的派生类不支持（Q_OBJECT）信号和槽
public:
    //explicit MyPlane(QGraphicsPixmapItem *parent = nullptr);
    Player();


signals:

public slots:
};

#endif // MYPLANE_H
