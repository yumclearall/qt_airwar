#include "Gameobject.h"
#include <QGraphicsScene>
#include "GameObjectpool.h"
#include <QtDebug>

int Gameobject::createCount = 0;
Gameobject::Gameobject(QObject* parent)
{
    createCount++;
    qDebug() << "当前创建" + QString::number(createCount) +  "个对象";
}

void Gameobject::GameObjectDelete(QGraphicsScene *_scene)
{
    _scene->removeItem(this);//移除场景
    GameObjectPool::Instance()->RecoveryGameObject(this);//回收对象
}

Gameobject::~Gameobject()
{
    createCount--;
    qDebug() << "当前释放第" + QString::number(createCount) +  "个对象";
}
