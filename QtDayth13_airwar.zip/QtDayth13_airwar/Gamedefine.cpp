#include "Gamedefine.h"

GameDefine::GameDefine()
{

}
