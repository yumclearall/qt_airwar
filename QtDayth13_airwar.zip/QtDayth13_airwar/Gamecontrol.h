#ifndef GAMECONTROL_H
#define GAMECONTROL_H


#include "Gamedefine.h"
//单例类
class GameControl : public QObject
{
    static GameControl* instance;    //对外初始化

    GameControl();  //构造函数私有化


public:

    //获取单例
    static GameControl* Insteace(){
        if (instance == nullptr)
            return  instance = new GameControl();
        return  instance;
    }

    //析构
    ~GameControl(){
//        if (instance != nullptr)
//            delete instance;
//        instance = nullptr;
    }

    //游戏初始化
    void GameInit();
    void LoadStartScence();//开始场景初始化
    void LoadGameScence();//游戏场景初始化

    //游戏逻辑定时器开启
    void GameStart();

    //游戏逻辑定时器关闭
    void GameOver();


    //背景移动函数
    void BGMove();


    //子弹生成函数
    void PlaneBulletShoot();

    //碰撞检测
    void Collision();

    //敌机生成函数
    void CreateEnemy();

    //按键组合
    QList<int> mKeyList;


protected:
    QGraphicsView mGameView;    //游戏视图
    QGraphicsScene mSence;      //场景

    //开始游戏场景
    QGraphicsScene mStartScence;

    //QGraphicsPixmapItem mPlane;     //飞机
    Player mMyPlane;
    QGraphicsPixmapItem mBackGround01;  //背景12
    QGraphicsPixmapItem mBackGround02;

    //背景移动定时器
    QTimer* mBGMoveTimer;
    //创建敌人定时器
    QTimer* mEnemyCreateTimer;
    //敌人移动定时器
    QTimer* mEnemyMoveTimer;

    //容器

    //子弹，管理所有子弹
    QList<PlayerBullet*> mBulletList;
    //敌人容器
    QList<Enemy*> mEnemyList;


    //飞机移动函数
    void PlantMove();



    //定时器

    //飞机移动检测定时器
    QTimer* mPlaneMoveTimer;

    //子弹发射定时器
    QTimer* mPLaneShootTimer;   //我方
    QTimer* mEnenyShootTimer;   //敌方

    //子弹移动定时器
    QTimer* mBulletMoveTimer;





    //背景音乐
    QMediaPlayer mMediaBG;

};

#endif // GAMECONTROL_H
