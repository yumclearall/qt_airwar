#include "playerbullet.h"

PlayerBullet::PlayerBullet(QObject* parent)
{
    mObjectType = Gameobject::OT_BulletPlayer;
    mBulletSpeed = 6;
}


void PlayerBullet::PlaySound()
{
    //if (mBulletType == BT_Palyer)
        mBulletMedia.setMedia(QUrl("qrc:/music/music/da.mp3"));
    //else if (mBulletType == BT_Enemy) {
       // mBulletMedia.setMedia(QUrl("qrc:/music/music/tong.mp3"));
    //}

    mBulletMedia.play();
   // mBulletMedia.pause(); //暂停
}

void PlayerBullet::Init(QPoint _pos, QPixmap _pixmap)
{
    this->setPos(_pos);
    this->setPixmap(_pixmap);
    mBulletSpeed = 6;
    //子弹调整
//    this->setScale((0.5));//缩放
//    this->setX(this->x() - this->scale()*pixmap().width()/2);

    //PlaySound();
}
