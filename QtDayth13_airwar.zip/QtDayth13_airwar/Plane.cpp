#include "Plane.h"

Plane::Plane(QObject *parent)
{
    mObjectType = Gameobject::OT_Player;
}
