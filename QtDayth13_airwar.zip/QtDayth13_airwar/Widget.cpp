#include "Widget.h"
#include "ui_Widget.h"
#include "Gamecontrol.h"

Widget* Widget::widget = nullptr;
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setWindowTitle("飞机大战");//窗口名
    //this->set

    //设置背景尺寸
    this->setFixedSize(GameDefine::ScreenWidth,GameDefine::ScreenHeight);
    widget = this;

}


Widget::~Widget()
{
    delete ui;
}


void Widget::keyPressEvent(QKeyEvent* event){
    switch (event->key()) {

    case Qt::Key_W  :
    case Qt::Key_Up :
//        mPlane.moveBy(0,-5);
//        break;
    case Qt::Key_S  :
    case Qt::Key_Down :
//        mPlane.moveBy(0,5);
//        break;
    case Qt::Key_A  :
    case Qt::Key_Left :
//        mPlane.moveBy(-5,0);
//        break;
    case Qt::Key_D  :
    case Qt::Key_Right :
//        mPlane.moveBy(5,0);
//        break;

        //添加按键组合
        GameControl::Insteace()->mKeyList.append(event->key());
        break;

    }
}

void Widget::keyReleaseEvent(QKeyEvent* event){
    //移除对应按键组合
    if (GameControl::Insteace()->mKeyList.contains(event->key()))
               GameControl::Insteace()->mKeyList.removeOne(event->key());
}








