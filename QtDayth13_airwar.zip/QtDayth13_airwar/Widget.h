#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
//#include "Gamedefine.h"
//#include <QGraphicsPixmapItem>     //图形元素
//#include <QGraphicsView>            //视图
//#include <QGraphicsScene>           //场景
//#include <QList>        //链表

//#include "Bullet.h"
//#include "Enemy.h"
//#include "Player.h"

//#include <QMediaPlayer>     //媒体播放器

//  图形元素组成 ----> 场景 ----->  视图

//窗口存在多个视图， 视图中设置一个场景， 场景添加多个图片元素

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

    static Widget* widget;


    //按键事件
    virtual void keyPressEvent(QKeyEvent* event);
    virtual void keyReleaseEvent(QKeyEvent* event);

private:
    Ui::Widget *ui;



};

#endif // WIDGET_H
