#ifndef BALLES_H
#define BALLES_H

#include "Gameobject.h"
#include <QDebug>

class Bullet : public Gameobject{

public:

    //子弹类型
    enum BullerType{
        BT_Palyer,  //我方子弹
        BT_Enemy    //敌方
    };


    Bullet(QObject *parent = nullptr);
    Bullet(QPoint _pos, QPixmap _pixmap, int _type);//type子弹类型

    ~Bullet(){
        qDebug() << "子弹被释放";
    }

    //移动函数
    void BulletMove(QPoint _dir = QPoint(0,-1));



protected:
    int mBulletType;    //子弹类型
    int mBulletSpeed;   //子弹速度

};

#endif // BALLES_H
