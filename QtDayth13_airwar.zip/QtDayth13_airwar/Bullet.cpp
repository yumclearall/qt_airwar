#include "Bullet.h"
#include "Gamedefine.h"

Bullet::Bullet(QObject *parent)
{
    mObjectType = Gameobject::OT_BulletPlayer;
}

Bullet::Bullet(QPoint _pos, QPixmap _pixmap, int _type)
{
    this->setPos(_pos);
    this->setPixmap(_pixmap);

//    this->mBulletType = _type;
//    this->mBulletSpeed = 10;

    //PlaySound();


    //子弹缩放
//    this->setScale(0.5);//qreal(0.5)
//    this->setX(this->x() + this->pixmap().width()/4);
}

void Bullet::BulletMove(QPoint _dir)
{
    this->moveBy(0, _dir.y() * mBulletSpeed);

}




