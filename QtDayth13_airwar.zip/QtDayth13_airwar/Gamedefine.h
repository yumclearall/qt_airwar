#ifndef GAMEDEFINE_H
#define GAMEDEFINE_H


#include <QMediaPlayer>     //音乐播放
#include <QDebug>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QTimer>
#include <QList>
#include <QToolButton>

#include "Enemy.h"
#include "Widget.h"
#include "Player.h"
#include "Bullet.h"
#include "playerbullet.h"
#include "enemybullet.h"




//游戏定义类
class GameDefine
{

    GameDefine();       //私有
public:
    static const int PlaneShootUpdateTime = 400; //子弹射击间隔
    static const int PlayerMoveUpdateTime = 10;     //飞机移速
    static const int EnemyMoveUpdateTime = 20;   //敌机移速
    static const int BackgroundUpdatetTime = 10;    //背景移速
    static const int BulletMoveTime = 10;       //子弹移速
    static const int EnemyCreateTime = 1000;

    //屏幕宽高
    static const int ScreenWidth = 400;
    static const int ScreenHeight = 600;






};

#endif // GAMEDEFINE_H
