#ifndef PLAYERBULLET_H
#define PLAYERBULLET_H

#include "Bullet.h"

class PlayerBullet : public Bullet
{
public:
    PlayerBullet(QObject *paretn = nullptr);
    //子弹音效函数
    void PlaySound();
    void Init(QPoint _pos, QPixmap _pixmap);
};

#endif // PLAYERBULLET_H
