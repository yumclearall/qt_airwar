#include "Player.h"

//MyPlane::MyPlane(QGraphicsPixmapItem *parent) : QGraphicsPixmapItem(parent)
Player::Player()
{
    this->setPixmap(QPixmap("://image/plane.png"));
    this->setPos(165,540);

    mMoveSpeed = 3;
    mShootSpeed = 500;
}
