#include "widget.h"
#include "ui_widget.h"
#include <QFileDialog>
#include <QPainter>
#include "gamemap.h"
#include <QMessageBox>

#include <QKeyEvent>
#include <QTimer>


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->resize(700,500);

    //初始化地图元素
    mMap = new GameMap(this);
    //QString filename = QFileDialog::getOpenFileName(this,"打开地图","./","*.txt");

    if (!mMap->InitByFile("./Map/Map01.txt")){
        QMessageBox::warning(this,"警告","文件打开失败");
    }

    mMapPainter = new QPainter(this);//创建画家
    mRose = new Rose(this);



    //mtimer = new QTimer(this);

    //定时调用更新函数
    //mtimer->start(200);
//    connect(mtimer,&QTimer::timeout,[this](){
//        this->update();
//    });

}

Widget::~Widget()
{
    delete ui;
}

//void Widget::DrawMap(int x, int y){
//    for (int i = 0; i < mMap->gRow; i++){
//        for (int j = 0; j < mMap->gCol; j++){
//            QString imgurl;
//            switch (mMap->gMap[i][j]) {
//                case Road: imgurl = "://image/sky.png"; break;
//                case Wall: imgurl = "://image/wall.png"; break;
//                case Box: imgurl = "://image/box.png"; break;
//                case Point: imgurl = "://image/point.png"; break;
//                case InPoint: imgurl = ":/image/inpoint.png"; break;
//            }
//            QImage img(imgurl);
//            mMapPainter->drawImage(QRect(y + j * img.width(), x + i * img.height(),img.width(),img.height()),QImage(imgurl));
//        }
//    }
//}

void Widget::paintEvent(QPaintEvent *event){
    mMapPainter->begin(this);   //设置画布

    //背景
    //QPainter bgPainter(this);
    //bgPainter.drawImage(QRect(0,0,400,400),QImage("://image/back.png"));
    mMapPainter->drawImage(QRect(0,0,700,500),QImage("://image/back.png"));


    //画地图
    //DrawMap(50,50);
    mMap->Paint(mMapPainter,QPoint(50,50));

    //画人物
    mRose->Paint(mMapPainter, QPoint(50,50));


    mMapPainter->end();         //结束
}


void Widget::keyPressEvent(QKeyEvent* event){

     //逻辑碰撞检测函数
    switch (event->key()) {
        case Qt::Key_W :
        case Qt::Key_Up:{
            Collision(-1,0);
            break;
        }
        case Qt::Key_S :
        case Qt::Key_Down:{
            Collision(1,0);
            break;
        }
        case Qt::Key_A :
        case Qt::Key_Left:{
            Collision(0,-1);
            break;
        }
        case Qt::Key_D :
        case Qt::Key_Right:{
            Collision(0,1);
            break;
        }
    }

    //更新打印
    this->update();
}


void Widget::Collision(int _row, int _col){
    //判断位置定义
    int newRow = mRose->rRow + _row;
    int newCol = mRose->rCol + _col;

    if (mMap->gMap[newRow][newCol] == Wall){        //判断前方是墙
        return;
    }else if(mMap->gMap[newRow][newCol] == Box){
        //定义箱子前方
        if (mMap->gMap[newRow + _row][newCol + _col] == Road){
            //改变地图元素
            mMap->gMap[newRow + _row][newCol + _col] = Box;
            mMap->gMap[newRow][newCol] = Road;
        }else if (mMap->gMap[newRow + _row][newCol + _col] == Point) {
            mMap->boxsum--;
            mMap->gMap[newRow + _row][newCol + _col] = InPoint;
            mMap->gMap[newRow][newCol] = Road;
        }else
            return;
    }else if(mMap->gMap[newRow][newCol] == InPoint){
        if (mMap->gMap[newRow + _row][newCol + _col] == Road){
            //改变地图元素
            mMap->boxsum++;
            mMap->gMap[newRow + _row][newCol + _col] = Box;
            mMap->gMap[newRow][newCol] = Point;
        }else if (mMap->gMap[newRow + _row][newCol + _col] == Point) {
            mMap->gMap[newRow + _row][newCol + _col] = InPoint;
            mMap->gMap[newRow][newCol] = Point;
        }else
            return;
    }
    mRose->Move(_row,_col);

    if (mMap->boxsum == 0){
       QMessageBox::warning(this,"通关啦","恭喜通关！");
    }
}
