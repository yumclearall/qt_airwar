#ifndef ROSE_H
#define ROSE_H

#include <QObject>
#include <QPoint>
#include <QImage>

class Rose : public QObject
{
    Q_OBJECT
public:
    explicit Rose(QObject* parent = nullptr);

    //对应在地图映射的行列
    int rRow, rCol;


    //画图位置
    QPoint rPointPos;
    //人物图片
    QImage rImage;

    void Move(int _row, int _col); //移动函数
    void Paint(QPainter *_p, QPoint _pos);

};

#endif // ROSE_H
