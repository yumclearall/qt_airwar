#ifndef GAMEMAP_H
#define GAMEMAP_H

#include <QObject>
#include <QPainter>
#include <QPoint>
enum MapElement{
    Road,
    Wall,
    Box,
    Point,
    InPoint
};

class GameMap:public QObject
{
public:
    explicit GameMap(QObject* parent = nullptr);
    ~GameMap();//析构，使用完后释放内存

    bool InitByFile(QString filename);
    void Clear();
    void Paint(QPainter* _p, QPoint _showPos);


    int gRow,gCol;
    int** gMap;//用于开辟二维数组， 2D地图元素
    //判断通关
    int boxsum;
};

#endif // GAMEMAP_H
