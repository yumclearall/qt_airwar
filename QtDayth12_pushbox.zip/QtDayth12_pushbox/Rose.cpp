#include "Rose.h"
#include <QPainter>

Rose::Rose(QObject* parent) : QObject(parent)
{
    rImage = QImage("://image/one.png");
    rRow = 1;
    rCol = 1;
    rPointPos = QPoint(rCol,rRow) * rImage.width();//显示位置
}
void Rose::Move(int _row, int _col){

    rRow += _row;
    rCol += _col;

    rPointPos = QPoint(rCol,rRow) * rImage.width();

}

void Rose::Paint(QPainter *_p, QPoint _pos){

    _p->drawImage(rPointPos +_pos,rImage);
}
