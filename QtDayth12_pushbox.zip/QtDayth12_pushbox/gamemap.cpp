#include "gamemap.h"
#include <QFile>
#include <QDebug>

GameMap::GameMap(QObject *parent) : QObject(parent)
{
    gRow = 0;
    gCol = 0;
    gMap = nullptr;

}

GameMap::~GameMap(){
    Clear();
}
void GameMap::Clear(){
    if (gMap != nullptr){
        for (int i = 0; i < gRow; i++){
            delete [] gMap[i];
        }
        delete [] gMap;
    }
}

bool GameMap::InitByFile(QString filename){
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)){
        return false;//打开失败
    }

    //读取所有内容
    QByteArray arrAll = file.readAll();
    arrAll.replace("\r\n","\n");//替换
    QList<QByteArray> lineArr = arrAll.split('\n');//分割子串

    gRow = lineArr.size() - 1;//确定行
    gMap = new int*[gRow];

    for (int i = 0; i < gRow; i++){
        QList<QByteArray> colList = lineArr[i].split(',');

        gCol = colList.size();//确定列
        gMap[i] = new int[gCol];//开辟列

        for (int j = 0; j < gCol; j++){//遍历列
           gMap[i][j] = colList[j].toInt();
        }
    }

}

void GameMap::Paint(QPainter* _p,QPoint _showPos){
    boxsum = 0;
    for (int i = 0; i < gRow; i++){
        for (int j = 0; j < gCol; j++){
            QString imgurl;
            if (gMap[i][j] == Box)
                boxsum++;
            switch (gMap[i][j]) {
                case Road: imgurl = "://image/sky.png"; break;
                case Wall: imgurl = "://image/wall.png"; break;
                case Box: imgurl = "://image/box.png"; break;
                case Point: imgurl = "://image/point.png"; break;
                case InPoint: imgurl = ":/image/inpoint.png"; break;
            }
            QImage img(imgurl);
            _p->drawImage(QRect(_showPos.x() + j * img.width(), _showPos.y() + i * img.height(),img.width(),img.height()),QImage(imgurl));
            //_p->drawImage(_showPos,img);


        }
    }
}
