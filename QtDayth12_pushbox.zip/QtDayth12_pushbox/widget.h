#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "gamemap.h"
#include "Rose.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);

    //画图事件
    virtual void paintEvent(QPaintEvent* event);

    //键盘按键
    virtual void keyPressEvent(QKeyEvent* event);
    void Collision(int _row, int _col); //判断碰撞

//    void DrawMap(int x, int y);//画地图

    ~Widget();

private:
    Ui::Widget *ui;

    GameMap* mMap;

    //画家
    QPainter* mMapPainter;

    //角色
    Rose* mRose;

    //游戏更新定时器
    //QTimer* mtimer;
};

#endif // WIDGET_H
