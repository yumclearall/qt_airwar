#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

namespace Ui {
class Widget;
}

enum BtnType{       //自定义按钮类型
    Num,        //数字
    Op,         //运算符
    Dot,        //点
    Equal,      //等于
    Clear,      //清除
    Back     //退格
};


class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();
public slots:
    void OnClicked(BtnType _typr, QString _btn);
private:
    Ui::Widget *ui;

    QString Wnum1;   //操作数1
    QString Wnum2;   //操作数2
    QString Wop;     //运算符
};



#endif // WIDGET_H
