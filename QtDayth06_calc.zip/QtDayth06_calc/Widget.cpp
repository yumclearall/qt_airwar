#include "Widget.h"
#include "ui_Widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    connect(ui->num0, &QPushButton::clicked,[this](){OnClicked(Num,"0");});
    connect(ui->num1, &QPushButton::clicked,[this](){OnClicked(Num,"1");});
    connect(ui->num2, &QPushButton::clicked,[this](){OnClicked(Num,"2");});
    connect(ui->num3, &QPushButton::clicked,[this](){OnClicked(Num,"3");});
    connect(ui->num4, &QPushButton::clicked,[this](){OnClicked(Num,"4");});
    connect(ui->num5, &QPushButton::clicked,[this](){OnClicked(Num,"5");});
    connect(ui->num6, &QPushButton::clicked,[this](){OnClicked(Num,"6");});
    connect(ui->num7, &QPushButton::clicked,[this](){OnClicked(Num,"7");});
    connect(ui->num8, &QPushButton::clicked,[this](){OnClicked(Num,"8");});
    connect(ui->num9, &QPushButton::clicked,[this](){OnClicked(Num,"9");});

    connect(ui->op_add, &QPushButton::clicked,[this](){OnClicked(Op,"+");});
    connect(ui->op_p, &QPushButton::clicked,[this](){OnClicked(Op,"-");});
    connect(ui->op_mul, &QPushButton::clicked,[this](){OnClicked(Op,"*");});
    connect(ui->op_del, &QPushButton::clicked,[this](){OnClicked(Op,"/");});

    connect(ui->clear, &QPushButton::clicked,[this](){OnClicked(Clear, "Clear");});
    connect(ui->backspace, &QPushButton::clicked,[this](){OnClicked(Back, "Back");});
    connect(ui->point, &QPushButton::clicked, [this](){OnClicked(Dot, ".");});
    connect(ui->op_equ, &QPushButton::clicked, [this](){OnClicked(Equal, "=");});

}

Widget::~Widget()
{
    delete ui;
}

void Widget::OnClicked(BtnType _type, QString _btn){
    switch (_type){
        case Num:       //数字
        {
            if (Wop.isEmpty()){     //运算符为空，说明输入的是操作数1
                Wnum1 += _btn;
            }else {                //运算符不为空，输入操作数2
                Wnum2 += _btn;
            }
            break;
        }
        case Op:        //运算符
        {
        if (Wnum1.isEmpty()){
            Wnum1 += _btn;
        }
        else if (Wnum2.isEmpty() && Wnum1.size() == 1 && (Wnum1.contains("+") || Wnum1.contains("-"))){
            ui->lineEdit_2->setText("格式错误！");
            Wop.clear();
            Wnum1.clear();
        }
            else  if (Wnum2.isEmpty()){

                Wop = _btn;
            }
            else {
                OnClicked(Equal,_btn);
                Wop = _btn;
            }
            break;
        }
        case Dot:{      //点
        if (Wop.isEmpty()){
            //操作数一的小数点
            if (!Wnum1.isEmpty() && !Wnum1.contains(".")){
                //操作数1没有点且不为空
                Wnum1 += _btn;
            }
        }else {
            //操作数2的点
            if (!Wnum2.isEmpty() && !Wnum2.contains(".")){
                Wnum2 += _btn;
            }
        }
            break;
        }
        case Clear:     //清除
        {
            Wnum1.clear();
            Wnum2.clear();
            Wop.clear();
            break;
        }
        case Equal:    //等于
        {
        if (Wnum1.isEmpty() || Wnum2.isEmpty() || Wop.isEmpty())
                return;
        double num01 = Wnum1.toDouble();
            double num02 = Wnum2.toDouble();
            double result = 0.0;
            if (Wop == "+"){
                result = num01 + num02;
            }else if (Wop == "-"){
            result = num01 - num02;
            }else if (Wop == "*") {
            result = num01 * num02;
            } else if (Wop == "/") {
                if (num02 == 0.0){
                    ui->lineEdit_2->setText("除数不能为0");
                    Wnum2.clear();
                    return;
                }
            result = num01 / num02;
        }
        Wnum1 = QString::number(result);
        Wop.clear();
        Wnum2.clear();
        ui->lineEdit_2->setText(QString::number(result));   //数字转成字符串
//        Wnum1 = result;
//        Wop.clear();
//        Wnum2.clear();
        break;
    }
        case Back:      //回退
        {
            if (!Wnum1.isEmpty() && !Wop.isEmpty() && !Wnum2.isEmpty())
                Wnum2.chop(1);  //尾部删除字符 指定个数
            else if (!Wnum1.isEmpty() && !Wop.isEmpty()) {
                Wop.clear();
            }else if (!Wnum1.isEmpty()){
                Wnum1.chop(1);
            }
    }
    }
    ui->lineEdit_1->setText(Wnum1 + Wop + Wnum2);
}
